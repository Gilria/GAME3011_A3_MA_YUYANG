using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameSweet : MonoBehaviour
{
    private int x;

    private int y;

    private GameManager.SweetsType type;
    //public int X { get => x;  set => x = value; }

    public int X
    {
        get
        {
            return x;
        }
        set
        {
            if (CanMove())
            {
                x = value;
            }
            
        }


    }

    public int Y
    {
        get
        {
            return y;
        }
        set
        {
            if (CanMove())
            {
                y = value;
            }

        }


    }
    //public int Y { get => y; set => y = value; }
    public GameManager.SweetsType Type { get => type; }
    

    private MoveSweet movedComponent;
    public MoveSweet MovedComponent { get => movedComponent;}


    
    public ColorSweet ColoredComponent { get => coloredComponent; }
    public ClearedSweet ClearComponent { get => clearComponent; }

    private ColorSweet coloredComponent;

    private ClearedSweet clearComponent;



    public bool CanMove()
    {
        return MovedComponent != null;
    }

    public bool CanColor()
    {
        return ColoredComponent!= null;
    }

    public bool CanClear()
    {
        return ClearComponent != null;
    }
    private void Awake()
    {
        movedComponent = GetComponent<MoveSweet>();
        coloredComponent = GetComponent<ColorSweet>();
        clearComponent = GetComponent<ClearedSweet>();
    }


    [HideInInspector]
    public GameManager gameManager;


    public void Init(int _x, int _y, GameManager _gameManager, GameManager.SweetsType _type)
    {
        x = _x;
        y = _y;
        gameManager = _gameManager;
        type = _type;
    }


    private void OnMouseEnter()
    {
        gameManager.EnterSweet(this);
    }


    private void OnMouseDown()
    {
        gameManager.PressSweet(this);
    }


    private void OnMouseUp()
    {
        gameManager.ReleaseSweet();
    }


    




}
