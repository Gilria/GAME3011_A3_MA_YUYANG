using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClearedSweet : MonoBehaviour
{

    public AnimationClip clearAnimation;

    private bool isClearing;

    public AudioClip destroyAudio;

    public bool IsClearing { get => isClearing; }

    protected GameSweet sweet;


    private void Awake()
    {
        sweet = GetComponent<GameSweet>();
    }

    public virtual void Clear()
    {
        isClearing = true;
        StartCoroutine(ClearCoroutine());
    }

    private IEnumerator ClearCoroutine()
    {
        Animator animator = GetComponent<Animator>();

        if (animator!=null)
        {
            animator.Play(clearAnimation.name);


            GameManager.Instance.playerScore++;

            AudioSource.PlayClipAtPoint(destroyAudio, transform.position);

            yield return new WaitForSeconds(clearAnimation.length);
            Destroy(gameObject);
        }
    }

}
