using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AAA : MonoBehaviour
{
    public GameObject gamePrefab;
    public GameObject menuPrefab;
    public GameObject overPrefab;
    public GameObject winPrefab;
    public int level = 10;
    void Start()
    {
        gamePrefab.SetActive(false);
        menuPrefab.SetActive(true);
        overPrefab.SetActive(false);

        


    }

    // Update is called once per frame
    void Update()
    {
        if (level <= 2)
        {
            gamePrefab.SetActive(true);
            menuPrefab.SetActive(false);
            overPrefab.SetActive(false);

        }
    }

    public void levelPick(int a)
    {
        level = a;
    }
}
